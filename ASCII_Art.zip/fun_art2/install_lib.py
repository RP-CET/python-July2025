import subprocess
import sys

subprocess.check_call([sys.executable, "-m", "pip", "install", "pywhatkit"])

 
try:
    import pywhatkit
    print("module 'pywhatkit' is installed")
except ModuleNotFoundError:
    print("module 'pywhatkit' is not installed")
    print("try running this Python script again")
