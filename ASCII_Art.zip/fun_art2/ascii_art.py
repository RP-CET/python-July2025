#https://medium.com/analytics-vidhya/turn-any-image-to-ascii-art-using-python-2ab2b1f7f523

import pywhatkit 

#display welcome msg
print("Let's turn images to ASCII art!")

#capture source and target path
source_path = 'Evie_Pig.png'
target_path = 'demo_ascii_art'


#call the method
pywhatkit.image_to_ascii_art(source_path, target_path)

read_file = open(target_path + ".txt")
data = read_file.read()

print (data)
#pywhatkit.sendwhatmsg("+65------",data, 16, 05)