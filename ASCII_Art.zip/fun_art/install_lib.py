import subprocess
import sys

subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "termcolor"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "colorama"])

try:
    import PIL
    print("module 'PIL' is installed")
except ModuleNotFoundError:
    print("module 'PIL' is not installed")
    print("try running this Python script again")
 
try:
    import termcolor
    print("module 'termcolor' is installed")
except ModuleNotFoundError:
    print("module 'termcolor' is not installed")
    print("try running this Python script again")
 
try:
    import colorama
    print("module 'colorama' is installed")
except ModuleNotFoundError:
    print("module 'colorama' is not installed")
    print("try running this Python script again")
