#https://www.fortytwo.my/landon-regular-dining-table-coffee.html

from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

site= "https://www.fortytwo.my/landon-regular-dining-table-coffee.html"
hdr = {'User-Agent': 'Mozilla/5.0'}
req = Request(site,headers=hdr)
page = urlopen(req)
soup = BeautifulSoup(page, 'html.parser')


elements = soup.select("#product-price-46728 > span:nth-child(1)") # RM298.00
print("Grabbed element elements : \n{}".format(elements))

price = elements[0].text
print("\nCurrent Price: " + price)

elements = soup.select("#old-price-46728")  #  RM433.00
old_price = elements[0].text
print("\nOld Price: " + old_price)



#The code below writes a record to a text file named "fortytwo_table.txt", in this format:
#<time> price: <price found>

'''
import datetime

x = datetime.datetime.now()

helloFile = open("fortytwo_table.txt", "a")
helloFile.write(str(x) + "\tprice: " + price + "\n")
helloFile.close()
'''