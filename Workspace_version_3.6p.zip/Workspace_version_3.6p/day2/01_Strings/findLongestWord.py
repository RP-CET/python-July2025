def findLongestWord( sentence ):
    words = sentence.split()

    longest = words[0]
    for word in words:
        if len(word) > len(longest):
            longest = word

    return longest


#=======================================
# Example of calling the function
sentence = "Python is an interpreted, high-level, general-purpose programming language."

print("Longest word: " + findLongestWord(sentence))