#this creates a file named hello2.txt
helloFile = open("hello2.txt", "w")
helloFile.write("I am teaching in RP today\nthis is 2nd line\n")
helloFile.write("how are you\n")
helloFile.close()


#change line 1 to the following and observe the outcome
#helloFile = open("hello2.txt", "a")
