from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

site= "https://webscraper.io/test-sites/e-commerce/static/computers/laptops"
hdr = {'User-Agent': 'Mozilla/5.0'}
req = Request(site,headers=hdr)
page = urlopen(req)
soup = BeautifulSoup(page, 'html.parser')



elements = soup.select(FIX_ME)  #  Packard 255 G2
print("Item: " + elements[0].text)


elements = soup.select(FIX_ME) # 416.99 
print("Price: " + elements[0].text)